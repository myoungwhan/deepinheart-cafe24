import 'dart:async';

import 'package:deepinheart/Controller/Viewmodel/counselor_appointment_provider.dart';
import 'package:deepinheart/Controller/Viewmodel/service_provider.dart';
import 'package:deepinheart/config/agora_config.dart';
import 'package:deepinheart/screens/calls/chat_screen.dart';
import 'package:deepinheart/screens/calls/video_call_screen.dart';
import 'package:deepinheart/screens/calls/voice_call_screen.dart';
import 'package:deepinheart/screens_consoler/models/appointment_model.dart';
import 'package:deepinheart/views/colors.dart';
import 'package:deepinheart/screens/home/widget/sub_category_chip.dart';
import 'package:deepinheart/screens_consoler/widgets/consultation_management/consultation_tab_bar.dart';
import 'package:deepinheart/views/custom_text.dart';
import 'package:deepinheart/views/font_constants.dart';
import 'package:deepinheart/views/rating_view.dart';
import 'package:deepinheart/views/ui_helpers.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';

class ConsultaionCardview extends StatefulWidget {
  final ConsultationTab type;
  final AppointmentData appointment;

  const ConsultaionCardview({
    Key? key,
    required this.type,
    required this.appointment,
  }) : super(key: key);

  @override
  State<ConsultaionCardview> createState() => _ConsultaionCardviewState();
}

class _ConsultaionCardviewState extends State<ConsultaionCardview> {
  Timer? _updateTimer;
  String _remainingTime = "";
  Color _remainingTimeColor = Colors.grey;
  bool _canJoin = false;

  @override
  void initState() {
    super.initState();
    _updateRemainingTime();
    // Update every 30 seconds for real-time feel
    _updateTimer = Timer.periodic(Duration(seconds: 30), (timer) {
      if (mounted) {
        _updateRemainingTime();
        // Also refresh appointments silently in the background
        _refreshAppointmentsSilently();
      }
    });
  }

  @override
  void dispose() {
    _updateTimer?.cancel();
    super.dispose();
  }

  void _updateRemainingTime() {
    setState(() {
      _remainingTime = _getRemainingTime();
      _remainingTimeColor = _getRemainingTimeColor();
      _canJoin = _canCounselorJoin();
    });
  }

  void _refreshAppointmentsSilently() {
    // Refresh appointments without showing loading indicator
    // context.read<CounselorAppointmentProvider>().fetchAppointmentsSilently(
    //   context,
    // );
  }

  AppointmentData get appointment => widget.appointment;
  ConsultationTab get type => widget.type;

  // Start video/voice call based on appointment method
  void _startCall(BuildContext context) {
    // Get channel name from appointment
    final channelName = appointment.chanelId;

    // Generate unique user ID for counselor
    final userId = AgoraConfig.generateUserId();

    // Get client/user name
    final clientName = appointment.user?.name ?? 'Client';

    // Counselor rate (you can get this from service data if available, using default 50.0)
    final counselorRate =
        appointment.reservedCoins > 0
            ? appointment.reservedCoins.toDouble()
            : 50.0;

    print('=== Starting Call ===');
    print('Channel Name: $channelName');
    print('User ID: $userId');
    print('Client: $clientName');
    print('Method: ${appointment.methodText}');
    print('Rate: $counselorRate');
    print('==================');

    // Navigate based on consultation method
    if (appointment.method.toLowerCase() == 'video_call') {
      Get.to(
        () => VideoCallScreen(
          counslername: clientName,
          channelName: channelName,
          userId: userId,
          counselorRate: counselorRate,
          appointmentId: appointment.id, // Pass appointment ID for coin updates
          isCounsler: true,
        ),
      );
    } else if (appointment.method.toLowerCase() == 'voice_call') {
      Get.to(
        () => VoiceCallScreen(
          isCounselor: true,
          counslername: clientName,
          channelName: channelName,
          userId: userId,
          counselorRate: counselorRate,
          appointmentId: appointment.id, // Pass appointment ID for coin updates
        ),
      );
    } else if (appointment.method.toLowerCase() == 'chat') {
      Get.to(
        () => ChatScreen(
          isCounselor: true,
          counselorName: clientName,
          channelName: channelName,
          userId: userId,
          counselorRate: counselorRate,
          appointmentId: appointment.id,
        ),
      );
    } else {
      // Default to video call
      Get.to(
        () => VideoCallScreen(
          counslername: clientName,
          channelName: channelName,
          userId: userId,
          counselorRate: counselorRate,
          appointmentId: appointment.id, // Pass appointment ID for coin updates
          isCounsler: true,
        ),
      );
    }
  }

  // Get color based on appointment status
  Color _getStatusColor() {
    if (appointment.isPending) {
      return Colors.orange; // Yellow/Orange for pending
    } else if (appointment.isCompleted || appointment.isAccepted) {
      return greenColor; // Green for confirmed or completed
    } else if (appointment.isDeclined) {
      return Colors.red; // Red for declined
    } else if (appointment.isInProgress) {
      return primaryColorConsulor; // Blue for in progress
    }
    return Colors.grey; // Default
  }

  // Get remaining time until appointment
  String _getRemainingTime() {
    if (appointment.date == null || appointment.timeSlot == null) {
      return appointment.statusText;
    }

    try {
      // Parse appointment date
      final dateParts = appointment.date!.split('-');
      if (dateParts.length != 3) return appointment.statusText;

      final year = int.parse(dateParts[0]);
      final month = int.parse(dateParts[1]);
      final day = int.parse(dateParts[2]);

      // Parse time from displayTime (e.g., "10:00 AM - 11:00 AM" or "10:00 - 11:00")
      final displayTime = appointment.timeSlot!.displayTime;
      final timeParts = displayTime.split(' - ');
      if (timeParts.isEmpty) return appointment.statusText;

      final startTimeStr = timeParts[0].trim();

      // Parse start time
      int hour = 0;
      int minute = 0;

      if (startTimeStr.contains('AM') || startTimeStr.contains('PM')) {
        // 12-hour format (e.g., "10:00 AM")
        final isPM = startTimeStr.contains('PM');
        final timeOnly = startTimeStr.replaceAll(RegExp(r'[APM\s]'), '');
        final hm = timeOnly.split(':');
        hour = int.parse(hm[0]);
        minute = hm.length > 1 ? int.parse(hm[1]) : 0;

        if (isPM && hour != 12) hour += 12;
        if (!isPM && hour == 12) hour = 0;
      } else {
        // 24-hour format (e.g., "10:00")
        final hm = startTimeStr.split(':');
        hour = int.parse(hm[0]);
        minute = hm.length > 1 ? int.parse(hm[1]) : 0;
      }

      final appointmentDateTime = DateTime(year, month, day, hour, minute);
      final now = DateTime.now();
      final difference = appointmentDateTime.difference(now);

      if (difference.isNegative) {
        return "Started".tr;
      }

      if (difference.inDays > 0) {
        return "${difference.inDays}d ${difference.inHours % 24}h ${"left".tr}";
      } else if (difference.inHours > 0) {
        return "${difference.inHours}h ${difference.inMinutes % 60}m ${"left".tr}";
      } else if (difference.inMinutes > 0) {
        return "${difference.inMinutes}m ${"left".tr}";
      } else {
        return "Starting soon".tr;
      }
    } catch (e) {
      return appointment.statusText;
    }
  }

  // Get color for remaining time
  Color _getRemainingTimeColor() {
    if (appointment.date == null || appointment.timeSlot == null) {
      return _getStatusColor();
    }

    try {
      final dateParts = appointment.date!.split('-');
      if (dateParts.length != 3) return _getStatusColor();

      final year = int.parse(dateParts[0]);
      final month = int.parse(dateParts[1]);
      final day = int.parse(dateParts[2]);

      final displayTime = appointment.timeSlot!.displayTime;
      final timeParts = displayTime.split(' - ');
      if (timeParts.isEmpty) return _getStatusColor();

      final startTimeStr = timeParts[0].trim();

      int hour = 0;
      int minute = 0;

      if (startTimeStr.contains('AM') || startTimeStr.contains('PM')) {
        final isPM = startTimeStr.contains('PM');
        final timeOnly = startTimeStr.replaceAll(RegExp(r'[APM\s]'), '');
        final hm = timeOnly.split(':');
        hour = int.parse(hm[0]);
        minute = hm.length > 1 ? int.parse(hm[1]) : 0;

        if (isPM && hour != 12) hour += 12;
        if (!isPM && hour == 12) hour = 0;
      } else {
        final hm = startTimeStr.split(':');
        hour = int.parse(hm[0]);
        minute = hm.length > 1 ? int.parse(hm[1]) : 0;
      }

      final appointmentDateTime = DateTime(year, month, day, hour, minute);
      final now = DateTime.now();
      final difference = appointmentDateTime.difference(now);

      if (difference.isNegative) {
        return Colors.blue; // Started
      } else if (difference.inHours < 1) {
        return Colors.orange; // Less than 1 hour
      } else if (difference.inHours < 24) {
        return greenColor; // Today
      } else {
        return Colors.grey; // Future
      }
    } catch (e) {
      return _getStatusColor();
    }
  }

  // Check if appointment time has been reached (for showing Join button)
  bool _isAppointmentTimeReached() {
    if (appointment.date == null || appointment.timeSlot == null) {
      return false;
    }

    try {
      final dateParts = appointment.date!.split('-');
      if (dateParts.length != 3) return false;

      final year = int.parse(dateParts[0]);
      final month = int.parse(dateParts[1]);
      final day = int.parse(dateParts[2]);

      final displayTime = appointment.timeSlot!.displayTime;
      final timeParts = displayTime.split(' - ');
      if (timeParts.isEmpty) return false;

      final startTimeStr = timeParts[0].trim();

      int hour = 0;
      int minute = 0;

      if (startTimeStr.contains('AM') || startTimeStr.contains('PM')) {
        final isPM = startTimeStr.contains('PM');
        final timeOnly = startTimeStr.replaceAll(RegExp(r'[APM\s]'), '');
        final hm = timeOnly.split(':');
        hour = int.parse(hm[0]);
        minute = hm.length > 1 ? int.parse(hm[1]) : 0;

        if (isPM && hour != 12) hour += 12;
        if (!isPM && hour == 12) hour = 0;
      } else {
        final hm = startTimeStr.split(':');
        hour = int.parse(hm[0]);
        minute = hm.length > 1 ? int.parse(hm[1]) : 0;
      }

      final appointmentDateTime = DateTime(year, month, day, hour, minute);
      final now = DateTime.now();

      // Time is reached if current time is at or after appointment time
      return now.isAfter(appointmentDateTime) ||
          now.isAtSameMomentAs(appointmentDateTime);
    } catch (e) {
      return false;
    }
  }

  // Check if counselor can join
  bool _canCounselorJoin() {
    // For scheduled appointments: time reached + status confirmed
    final isScheduledAppointmentReady =
        appointment.type.toLowerCase() == 'appointment' &&
        _isAppointmentTimeReached() &&
        appointment.statusText == "Confirmed";

    // For consult_now: counselor accepted + status upcoming
    final isConsultNowReady =
        appointment.type.toLowerCase() == 'consult_now' &&
        appointment.counselorStatus.toLowerCase() == 'accept' &&
        appointment.status.toLowerCase() == 'upcoming';

    return isScheduledAppointmentReady || isConsultNowReady;
  }

  // View chat history for completed chat appointments (no coin deduction)
  void _viewChatHistory(BuildContext context) {
    final channelName = appointment.chanelId;
    final userId = AgoraConfig.generateUserId();
    final clientName = appointment.user?.name ?? 'Client';

    Get.to(
      () => ChatScreen(
        isCounselor: true,
        counselorName: clientName,
        channelName: channelName,
        userId: userId,
        appointmentId: appointment.id,
        isViewOnly: true, // View-only mode - no coin deduction
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      shape: RoundedRectangleBorder(
        side: BorderSide(color: borderColor, width: .5),
        borderRadius: BorderRadius.circular(16.r),
      ),
      child: SizedBox(
        width: Get.width,
        child: Padding(
          padding: EdgeInsets.all(15),
          child: Row(
            children: [
              Expanded(
                flex: 2,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        CustomText(
                          text: appointment.user!.name,
                          align: TextAlign.start,
                          weight: FontWeightConstants.medium,
                        ),
                        UIHelper.horizontalSpaceSm,
                        type == ConsultationTab.reservation
                            ?
                            // SubCategoryChip(
                            //   text: "Online",
                            //   color: Colors.green,
                            //   isHaveCircle: true,
                            // )
                            Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Container(
                                  width: 10,
                                  height: 10,
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    color: GreenColor,
                                  ),
                                ),
                                UIHelper.horizontalSpaceSm5,
                                CustomText(
                                  text: "Online",
                                  fontSize: FontConstants.font_12,
                                  color: greenColor,
                                ),
                              ],
                            )
                            : MyRatingView(
                              initialRating: 4.0,
                              isAllowRating: false,
                              itemSize: 12.0,
                              fsize: FontConstants.font_12,
                              text: "4.0",
                            ),
                      ],
                    ),
                    UIHelper.verticalSpaceSm5,
                    CustomText(
                      text: appointment.displayDateTime,
                      fontSize: FontConstants.font_12,
                      color: lightGREY,
                    ),
                    UIHelper.verticalSpaceSm5,
                    CustomText(
                      text:
                          "${appointment.methodText}${appointment.timeSlot?.displayTime != null ? ' · ${appointment.timeSlot!.displayTime}' : ''}",
                      fontSize: FontConstants.font_12,
                      color: lightGREY,
                    ),
                    UIHelper.verticalSpaceSm5,
                    type != ConsultationTab.reservation
                        ? CustomText(
                          text: appointment.counsultaionContent ?? "No details".tr,
                          fontSize: FontConstants.font_12,
                          color: greenColor,
                        )
                        : Container(),
                  ],
                ),
              ),

              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  type == ConsultationTab.completed
                      ? Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          SubCategoryChip(text: 'Completed'.tr, color: greenColor),
                          SizedBox(height: 8.h),
                          // Show View Chat button for chat method appointments
                          if (appointment.method.toLowerCase() == 'chat')
                            GestureDetector(
                              onTap: () => _viewChatHistory(context),
                              child: Container(
                                padding: EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                                decoration: BoxDecoration(
                                  color: Colors.blue.shade50,
                                  borderRadius: BorderRadius.circular(12),
                                  border: Border.all(color: Colors.blue.shade200, width: 1),
                                ),
                                child: Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Icon(
                                      Icons.chat_bubble_outline,
                                      color: Colors.blue.shade700,
                                      size: 12,
                                    ),
                                    SizedBox(width: 4),
                                    CustomText(
                                      text: "View Chat".tr,
                                      fontSize: FontConstants.font_11,
                                      weight: FontWeightConstants.bold,
                                      color: Colors.blue.shade700,
                                    ),
                                  ],
                                ),
                              ),
                            )
                          else
                          MaterialButton(
                            height: 30.h,
                            shape: RoundedRectangleBorder(
                              side: BorderSide(color: Colors.grey),
                              borderRadius: BorderRadius.circular(30.r),
                            ),
                            onPressed: () {},
                            child: CustomText(
                              text: 'Details'.tr,
                              color: Colors.black,
                              fontSize: FontConstants.font_12,
                            ),
                          ),
                        ],
                      )
                      : Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        mainAxisSize: MainAxisSize.min,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          // Show Join button if appointment time reached and confirmed
                          // Otherwise show remaining time for appointment type, status for consult_now
                          _canJoin
                              ? GestureDetector(
                                onTap: () => _startCall(context),
                                child: SubCategoryChipCategory(
                                  text: "Join Now".tr,
                                  color: primaryColorConsulor,
                                  fontSize: FontConstants.font_12,
                                  isBackgroundDark: true,
                                ),
                              )
                              : appointment.type.toLowerCase() == 'appointment'
                              ? SubCategoryChip(
                                text: _remainingTime,
                                color: _remainingTimeColor,
                              )
                              : SubCategoryChip(
                            text: appointment.statusText,
                            color: _getStatusColor(),
                          ),

                          //    UIHelper.verticalSpaceSm5,
                          appointment.statusText == "Pending"
                              ? Padding(
                                padding: EdgeInsets.only(top: 8.h),
                                child: Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    //accept and decline small text buttons
                                    GestureDetector(
                                      onTap: () async {
                                        final success = await context
                                            .read<
                                              CounselorAppointmentProvider
                                            >()
                                            .acceptAppointment(
                                              context: context,
                                              appointmentId: appointment.id,
                                            );

                                        // If acceptance successful, start the call
                                        if (success) {
                                          if (appointment.type.toLowerCase() ==
                                              'consult_now') {
                                          _startCall(context);
                                          }
                                        }
                                      },
                                      child: SubCategoryChipCategory(
                                        text: "Accept".tr,
                                        color: primaryColorConsulor,
                                        fontSize: FontConstants.font_10,
                                        isBackgroundDark: true,
                                      ),
                                    ),
                                    UIHelper.horizontalSpaceSm5,
                                    GestureDetector(
                                      onTap: () async {
                                        // confirmation dialog
                                        UIHelper.showDialogOk(
                                          context,
                                          title: 'Decline Appointment'.tr,
                                          message:
                                              'Are you sure you want to decline this appointment?'.tr,
                                          onConfirm: () {
                                            Get.back();
                                            // decline appointment
                                            context
                                                .read<
                                                  CounselorAppointmentProvider
                                                >()
                                                .declineAppointment(
                                                  context: context,
                                                  appointmentId: appointment.id,
                                                );
                                          },
                                        );
                                      },
                                      child: SubCategoryChipCategory(
                                        text: "Decline".tr,
                                        color: Colors.red,
                                        fontSize: FontConstants.font_10,
                                        isBackgroundDark: true,
                                      ),
                                    ),
                                  ],
                                ),
                              )
                              : Padding(
                                padding: EdgeInsets.only(top: 8.0),
                                child:
                                    appointment.statusText == "Confirmed"
                                        ? SubCategoryChipCategory(
                                          text: "Reschedule".tr,
                                          color: Colors.white,
                                          textColor: Colors.black,
                                          borderColor: Colors.grey,
                                        )
                                        : appointment.statusText ==
                                            enumServiceStatus.Declined.name
                                        ? Container()
                                        : SubCategoryChip(
                                          text: "End Session".tr,
                                          color: Colors.red,
                                        ),
                              ),
                        ],
                      ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
