import 'package:deepinheart/Controller/Viewmodel/counselor_appointment_provider.dart';
import 'package:deepinheart/screens_consoler/models/appointment_model.dart';
import 'package:deepinheart/screens_consoler/widgets/consultation_management/consultaion_cardview.dart';
import 'package:deepinheart/views/colors.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:deepinheart/views/custom_text.dart';
import 'package:deepinheart/views/font_constants.dart';
import 'package:deepinheart/views/ui_helpers.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';
import 'consultation_tab_bar.dart';
import 'consultation_calendar.dart';

class ConsultationManagementView extends StatefulWidget {
  const ConsultationManagementView({Key? key}) : super(key: key);

  @override
  _ConsultationManagementViewState createState() =>
      _ConsultationManagementViewState();
}

class _ConsultationManagementViewState
    extends State<ConsultationManagementView> {
  ConsultationTab selectedTab = ConsultationTab.reservation;
  DateTime? selectedDate;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final provider = Provider.of<CounselorAppointmentProvider>(
        context,
        listen: false,
      );
      provider.fetchAppointments(context);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 2,

      shape: RoundedRectangleBorder(
        side: BorderSide(width: 1, color: borderColor),
        borderRadius: BorderRadius.circular(16.r),
      ),
      child: SizedBox(
        width: Get.width,

        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header
            Padding(
              padding: const EdgeInsets.all(10.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Expanded(
                    flex: 1,
                    child: CustomText(
                      align: TextAlign.start,
                      text: 'Consultation\nManagement'.tr,
                      fontSize: FontConstants.font_18,
                      height: 1.3,
                      weight: FontWeightConstants.semiBold,
                      color: Color(0xFF111726),
                    ),
                  ),
                  // UIHelper.horizontalSpaceSm,
                  Expanded(
                    flex: 1,
                    child: ConsultationTabBar(
                      selectedTab: selectedTab,
                      onTabChanged: (tab) {
                        setState(() {
                          selectedTab = tab;
                        });
                      },
                    ),
                  ),
                ],
              ),
            ),
            Divider(thickness: 1, color: borderColor),

            //UIHelper.verticalSpaceMd,

            // Content based on selected tab
            _buildTabContent(),
            UIHelper.verticalSpaceMd,
          ],
        ),
      ),
    );
  }

  Widget _buildTabContent() {
    return Consumer<CounselorAppointmentProvider>(
      builder: (context, provider, child) {
        if (provider.isLoading) {
          return Padding(
            padding: EdgeInsets.all(50),
            child: Center(child: CircularProgressIndicator()),
          );
        }

        if (provider.error != null) {
          return Padding(
            padding: EdgeInsets.all(20),
            child: Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  CustomText(
                    text: '${"Error".tr}: ${provider.error}',
                    color: Colors.red,
                    fontSize: FontConstants.font_14,
                  ),
                  UIHelper.verticalSpaceSm,
                  ElevatedButton(
                    onPressed: () => provider.fetchAppointments(context),
                    child: CustomText(text: 'Retry'.tr),
                  ),
                ],
              ),
            ),
          );
        }

        switch (selectedTab) {
          case ConsultationTab.reservation:
            return _buildAppointmentList(
              provider.appointments
                  .where(
                    (appointment) =>
                        appointment.status.toLowerCase() != 'confirmed',
                  )
                  .toList(),
            );

          case ConsultationTab.completed:
            return _buildAppointmentList(provider.completedAppointments);

          case ConsultationTab.schedule:
            return _buildScheduleView(provider);
        }
      },
    );
  }

  Widget _buildAppointmentList(List<AppointmentData> appointments) {
    if (appointments.isEmpty) {
      return Padding(
        padding: EdgeInsets.all(50),
        child: Center(
          child: CustomText(
            text: 'No appointments found'.tr,
            color: lightGREY,
            fontSize: FontConstants.font_14,
          ),
        ),
      );
    }

    return Builder(
      builder: (context) {
        return ListView.builder(
          itemCount: appointments.length,
          shrinkWrap: true,
          physics: NeverScrollableScrollPhysics(),
          itemBuilder:
              (context, index) => Padding(
                padding: const EdgeInsets.symmetric(horizontal: 5),
                child: ConsultaionCardview(
                  type: selectedTab,
                  appointment: appointments[index],
                ),
              ),
        );
      },
    );
  }

  Widget _buildScheduleView(CounselorAppointmentProvider provider) {
    final consultationDates = provider.appointmentDates;

    return ConsultationCalendar(
      selectedDate: selectedDate,
      onDateSelected: (date) {
        setState(() {
          selectedDate = date;
        });
      },
      consultationDates: consultationDates,
    );
  }
}
